# HTML + CSS

## Instructions

Using the starter code found in the `Unsolved` folder, use CSS to style the page and position elements according to the design in the following image:

![](html-css-mockup.png)
